﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_GameBot
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string process_name = "";
        public MainWindow()
        {
            InitializeComponent();
            show_process();
        }
        public void show_process()
        {
            Process[] processCollection = Process.GetProcesses();
            foreach (Process p in processCollection)
            {
                list_process.Items.Add(p.ProcessName);
            }
        }

        private void List_process_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            process_name = 
        }
    }
}
